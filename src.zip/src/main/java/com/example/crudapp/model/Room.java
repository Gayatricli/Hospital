package com.example.crudapp.model;


import jakarta.persistence.*;

@Entity
public class Room {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private int room_id;

    private String room_type;
    private int room_number;
    private String occupied;
    //private int patient_id;       //(Use when join url is not requested for room and patients)

    //@OnetoOne
    //@JoinColumn(name="patient_id")  (Use only when join url is requested by user to display the respective columns)
    //private Patients patients;

    public int getRoom_id() {
        return room_id;
    }
    public void setRoom_id(int room_id) {
        this.room_id = room_id;
    }
    public String getRoom_type() {
        return room_type;
    }
    public void setRoom_type(String room_type) {
        this.room_type = room_type;
    }
    public int getRoom_number() {
        return room_number;
    }
    public void setRoom_number(int room_number) {
        this.room_number = room_number;
    }
    public String getOccupied() {
        return occupied;
    }
    public void setOccupied(String occupied) {
        this.occupied = occupied;
    }
   // public int getPatient_id() {
      //  return patient_id;
    //}
   // public void setPatient_id(int patient_id) {
      //  this.patient_id = patient_id;
    //}
}
