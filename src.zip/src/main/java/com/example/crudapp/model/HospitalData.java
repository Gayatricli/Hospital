package com.example.crudapp.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;




@Entity

public class HospitalData {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)

    private int id;
    private String date;
    private Long mobile;
    private String name;
    private String reason;

    public HospitalData(int id, String date,Long mobile, String name, String reason) {
        this.id =  id;
        this.date = String.valueOf(date);
        this.mobile = Long.valueOf(String.valueOf(mobile));
        this.name = name;
        this.reason = reason;
    }

    public HospitalData() {

    }


    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }

    public String getDate() {
        return date;

    }
    public void setDate(int date) {
        this.date = String.valueOf(date);
    }

    public Long getMobile() {
        return mobile;
    }
    public void setMobile(Long mobile) {
        this.mobile = Long.valueOf(String.valueOf(mobile));
    }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public String getReason() {
        return reason;
    }
    public void setReason(String reason) {
        this.reason = reason;
    }

    @Override
    public String toString() {
        return String.format(
                "HospitalData[id=%d,date=%s,mobile=%s,name=%s,reason=%s]",
                id, date, mobile, name, reason);
    }

}
