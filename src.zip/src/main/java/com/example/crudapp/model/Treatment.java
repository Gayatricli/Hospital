package com.example.crudapp.model;

import jakarta.persistence.Entity;

import jakarta.persistence.*;

@Entity
public class Treatment {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private int treatment_id;


    private int doctor_id;
    private String treatment_describe;
    private int start_date;
    private int end_date;


    @OneToOne
    @JoinColumn(name="patient_id")
    private  Patients patients;


    public int getTreatment_id() {
        return treatment_id;
    }
    public void setTreatment_id(int treatment_id) {
        this.treatment_id = treatment_id;
    }
    public int getDoctor_id() {
        return doctor_id;
    }
    public void setDoctor_id(int doctor_id) {
        this.doctor_id = doctor_id;
    }
    public String getTreatment_describe() {
        return treatment_describe;
    }
    public void setTreatment_describe(String treatment_describe) {
        this.treatment_describe = treatment_describe;
    }
    public int getStart_date() {
        return start_date;
    }
    public void setStart_date(int start_date) {
        this.start_date = start_date;
    }
    public int getEnd_date() {
        return end_date;
    }
    public void setEnd_date(int end_date) {
        this.end_date = end_date;
    }
}
