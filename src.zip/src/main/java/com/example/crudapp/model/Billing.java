package com.example.crudapp.model;
import jakarta.persistence.Entity;

import jakarta.persistence.*;

@Entity
public class Billing {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private int billing_id;


    private int total_amount;
    private String payment_status;
    private  int billing_date;


    @ManyToOne
    @JoinColumn(name="id_patient")
     private Payment payment;


    public int getBilling_id() {
        return billing_id;
    }
    public void setBilling_id(int billing_id) {
        this.billing_id = billing_id;
    }
    public int getTotal_amount() {
        return total_amount;
    }
    public void setTotal_amount(int total_amount) {
        this.total_amount = total_amount;
    }
    public String getPayment_status() {
        return payment_status;
    }
    public void setPayment_status(String payment_status) {

        this.payment_status = payment_status;
    }
    public int getBilling_date() {
        return billing_date;
    }
    public void setBilling_date(int billing_date) {
        this.billing_date = billing_date;
    }
}
