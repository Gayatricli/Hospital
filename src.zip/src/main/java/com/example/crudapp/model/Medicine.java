package com.example.crudapp.model;

import jakarta.persistence.Entity;

import jakarta.persistence.*;

@Entity
public class Medicine {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)

    private int medicine_id;

    private String medicine_name;
    private int price;

    @OneToOne
    @JoinColumn(name="id")
    private Treatment treatment;

    public int getMedicine_id() {
        return medicine_id;
    }
    public void setMedicine_id(int medicine_id) {
        this.medicine_id = medicine_id;
    }
    public String getMedicine_name() {
        return medicine_name;
    }
    public void setMedicine_name(String medicine_name) {
        this.medicine_name = medicine_name;
    }
    public int getPrice() {
        return price;
    }
    public void setPrice(int price) {
        this.price = price;
    }

}
