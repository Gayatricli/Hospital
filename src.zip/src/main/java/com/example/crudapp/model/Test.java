package com.example.crudapp.model;


import jakarta.persistence.*;

@Entity
public class Test {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int test_id;

    @OneToOne
    @JoinColumn(name="p_id")
    private Patients patient;

   // private int p_id;

    private String test_type;
    private String result;
    private int test_date;

    public int getTest_id() {
        return test_id;
    }
    public void setTest_id(int test_id) {
        this.test_id = test_id;
    }
    //public int getP_id() {
        //return p_id;
    //}
   // public void setP_id(int p_id) {
        //this.p_id = p_id;
    //}
    public String getTest_type() {
        return test_type;
    }
    public void setTest_type(String test_type) {
        this.test_type = test_type;
    }
    public String getResult() {
        return result;
    }
    public void setResult(String result) {
        this.result = result;
    }
    public int getTest_date() {
        return test_date;
    }
    public void setTest_date(int test_date) {
        this.test_date = test_date;
    }


}
