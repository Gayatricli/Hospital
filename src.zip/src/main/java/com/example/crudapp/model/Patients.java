package com.example.crudapp.model;

import jakarta.persistence.*;

@Entity
public class Patients{

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String patient_name;
    private String doctor_name;
    private String discharge_status;


    @ManyToOne
    @JoinColumn(name="admission_id")

    private HospitalData hospitalData;

    public int getId() {
        return id;

    }
    public void setId(int id) {
        this.id = id;
    }
    public String getPatient_name() {
        return patient_name;
    }
    public void setPatient_name(String patient_name) {
        this.patient_name = patient_name;
    }
    public String getDoctor_name() {
        return doctor_name;
    }
    public void setDoctor_name(String doctor_name) {
        this.doctor_name = doctor_name;
    }
    public String getDischarge_status() {
        return discharge_status;
    }
    public void setDischarge_status(String discharge_status) {
        this.discharge_status = discharge_status;
    }
    private HospitalData getHospitalData() {
        return hospitalData;
    }
    public void setHospitalData(HospitalData hospitalData) {
        this.hospitalData = hospitalData;
    }
}








