package com.example.crudapp.repository;

import com.example.crudapp.model.Patients;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PatientsRepo extends JpaRepository<Patients, Integer> {
}
