package com.example.crudapp.repository;

import com.example.crudapp.model.Treatment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface Treatmentrepo extends JpaRepository<Treatment, Integer> {

}
