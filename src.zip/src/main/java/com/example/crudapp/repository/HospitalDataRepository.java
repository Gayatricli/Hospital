package com.example.crudapp.repository;

import com.example.crudapp.model.HospitalData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


public interface HospitalDataRepository extends JpaRepository<HospitalData,Integer> {
      HospitalData findById(int id);

}
