package com.example.crudapp;

import com.example.crudapp.model.HospitalData;
import com.example.crudapp.repository.HospitalDataRepository;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;

@SpringBootApplication

public class CrudappApplication extends SpringBootServletInitializer {
    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(CrudappApplication.class);
    }

    private static final Logger log = LoggerFactory.getLogger(CrudappApplication.class);

    public static void main(String[] args) {
        SpringApplication.run(CrudappApplication.class, args);
    }

    @Bean
    public CommandLineRunner demo(HospitalDataRepository repository) {
        return (args) -> {
            log.info("Patient found with findAll():");
            log.info("-------------------------------");
            repository.findAll().forEach(hospitaldata -> {
                log.info(hospitaldata.toString());
            });

            HospitalData hospitaldata = repository.findById(4);
            log.info("Patient found with findById(" + 4 + "):");
            log.info("-------------------------------");
            log.info(hospitaldata.toString());
            log.info("");


            repository.save(new HospitalData(45, "20180513", Long.valueOf(756432), "Gayatri", "malaria"));
            log.info("");
            repository.save(new HospitalData(46, "20190722", Long.valueOf(9898765), "Suparna", "Malaria"));
            log.info("");

        };
    }
}


