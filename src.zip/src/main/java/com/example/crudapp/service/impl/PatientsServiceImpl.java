package com.example.crudapp.service.impl;

import com.example.crudapp.model.Patients;
import com.example.crudapp.repository.PatientsRepo;
import com.example.crudapp.service.PatientsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PatientsServiceImpl implements PatientsService {
    @Autowired
    PatientsRepo patientsRepo;


    @Override
    public Patients create(Patients patient) {

        return patientsRepo.save(patient);
    }

    @Override
    public List<Patients> getAllPatients() {
        return patientsRepo.findAll();
    }
}
