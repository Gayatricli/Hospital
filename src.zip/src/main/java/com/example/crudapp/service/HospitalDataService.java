package com.example.crudapp.service;

import com.example.crudapp.model.HospitalData;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface HospitalDataService {
    public HospitalData create(HospitalData hospitalData);

    public HospitalData update(HospitalData hospitalData);

    public String deleteHospitalData(Integer id);

    public Optional<HospitalData> findById(Integer id);

    public List<HospitalData> getAllHospitalData();


}
