package com.example.crudapp.service.impl;


import com.example.crudapp.model.Treatment;

import com.example.crudapp.repository.Treatmentrepo;
import com.example.crudapp.service.TreatmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class Treatmentserviceimpl implements TreatmentService {
    @Autowired
    Treatmentrepo treatmentrepo;

    @Override
    public List<Treatment> getAllTreatments() {
        return treatmentrepo.findAll();
    }

    @Override
    public Treatment addTreatment(Treatment treatment) {
        return treatmentrepo.save(treatment);
    }

    @Override
    public Optional<Treatment> getTreatmentById(int treatment_id) {
        return treatmentrepo.findById(treatment_id);
    }

}
