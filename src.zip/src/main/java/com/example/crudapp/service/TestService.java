package com.example.crudapp.service;


import com.example.crudapp.model.Patients;
import com.example.crudapp.model.Test;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import java.util.List;

@Service
public interface TestService {
    public List<Test> getAllTests();

}
