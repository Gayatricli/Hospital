package com.example.crudapp.service.impl;


import com.example.crudapp.model.Payment;
import com.example.crudapp.repository.Paymentrepo;
import com.example.crudapp.service.paymentservice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class paymentserviceimpl implements paymentservice {
    @Autowired
    private Paymentrepo paymentrepo;

    @Override
    public Payment changePaymentStatus(Payment payment) {
        return paymentrepo.save(payment);
    }
}
