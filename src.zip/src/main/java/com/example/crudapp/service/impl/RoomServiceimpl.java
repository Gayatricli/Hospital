package com.example.crudapp.service.impl;

import com.example.crudapp.model.Room;
import com.example.crudapp.repository.RoomRepo;
import com.example.crudapp.service.RoomService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RoomServiceimpl implements RoomService {

    @Autowired
    RoomRepo roomRepo;

    @Override
    public List<Room> getAllRooms() {
        return roomRepo.findAll();
    }
}
