package com.example.crudapp.service;


import com.example.crudapp.model.Room;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface RoomService {

    public List<Room> getAllRooms();

}
