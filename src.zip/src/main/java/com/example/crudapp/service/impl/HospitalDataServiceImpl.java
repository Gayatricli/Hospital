package com.example.crudapp.service.impl;

import com.example.crudapp.model.HospitalData;
import com.example.crudapp.model.Patients;
import com.example.crudapp.repository.HospitalDataRepository;
import com.example.crudapp.service.HospitalDataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.List;
import java.util.Optional;

@Service
public class HospitalDataServiceImpl implements HospitalDataService {
    @Autowired
    HospitalDataRepository hospitalDataRepository;

    @Override
    public HospitalData create(HospitalData hospitalData) {
        return hospitalDataRepository.save(hospitalData);
    }
    @Override
    public List<HospitalData> getAllHospitalData() {
        return hospitalDataRepository.findAll();
    }

    @Override
    public HospitalData update(HospitalData hospitalData) {
        return hospitalDataRepository.save(hospitalData);
    }

    @Override
    public String deleteHospitalData(Integer id) {
         hospitalDataRepository.deleteById(id);
         return "Hospital Data Deleted Successfully";
    }

    @Override
    public Optional<HospitalData> findById(Integer id) {
        return Optional.ofNullable(hospitalDataRepository.findById(4));
    }

}
