package com.example.crudapp.service.impl;

import com.example.crudapp.model.Billing;
import com.example.crudapp.service.BillingService;
import org.springframework.stereotype.Service;
import com.example.crudapp.repository.Billingrepo;
import com.example.crudapp.service.BillingService;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Optional;


@Service
public class BillingServiceImpl implements BillingService {

    @Autowired
    Billingrepo billingrepo;


    @Override
    public List<Billing> findAll() {
        return  billingrepo.findAll();
    }
}
