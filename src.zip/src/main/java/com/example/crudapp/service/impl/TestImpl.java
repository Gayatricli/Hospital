package com.example.crudapp.service.impl;

import com.example.crudapp.model.Patients;
import com.example.crudapp.model.Test;
import com.example.crudapp.repository.TestRepo;
import com.example.crudapp.service.TestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.sql.*;
import java.util.List;

@Service
public class TestImpl implements TestService {

    @Autowired
    TestRepo testRepo;


    @Override
    public List<Test> getAllTests() {
        return testRepo.findAll();
    }


}
