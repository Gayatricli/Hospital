package com.example.crudapp.service;
import com.example.crudapp.model.Payment;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public interface paymentservice {
    public Payment changePaymentStatus(Payment payment);

}
