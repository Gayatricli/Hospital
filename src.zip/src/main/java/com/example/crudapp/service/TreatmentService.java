package com.example.crudapp.service;

import com.example.crudapp.model.Treatment;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface TreatmentService {
    public List<Treatment> getAllTreatments();
    public Treatment addTreatment(Treatment treatment);
    public Optional<Treatment> getTreatmentById(int id);

}
