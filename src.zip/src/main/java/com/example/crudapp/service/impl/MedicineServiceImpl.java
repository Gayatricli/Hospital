package com.example.crudapp.service.impl;

import com.example.crudapp.model.Medicine;
import com.example.crudapp.repository.Medicinerepo;
import com.example.crudapp.service.MedicineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MedicineServiceImpl implements MedicineService {
   @Autowired
   Medicinerepo medicineRepo;

    @Override
    public List<Medicine> getAllMedicine() {
        return medicineRepo.findAll();
    }

}
