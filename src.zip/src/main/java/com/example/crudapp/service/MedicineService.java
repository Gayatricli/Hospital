package com.example.crudapp.service;

import com.example.crudapp.model.Medicine;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface MedicineService {
    public List<Medicine> getAllMedicine();
}