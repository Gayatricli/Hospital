package com.example.crudapp.service;
import org.springframework.stereotype.Service;
import com.example.crudapp.model.Patients;

import java.util.List;


@Service
public interface PatientsService {
    public Patients create(Patients patient);
    public List<Patients> getAllPatients();
}
