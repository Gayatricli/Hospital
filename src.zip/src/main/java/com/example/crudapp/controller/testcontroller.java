package com.example.crudapp.controller;


import com.example.crudapp.model.Patients;
import com.example.crudapp.model.Test;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.servlet.ModelAndView;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@Controller
public class testcontroller {

       @GetMapping("/testform1/{p_id}")
       public String showUserTestForm(@PathVariable("p_id") int p_id, Model model) {
           model.addAttribute("p_id", p_id);
           model.addAttribute("test",new Test());
           return "testform1";
       }
       @GetMapping("/testresult1/{p_id}")
       public String showUserTestResult(@PathVariable("p_id") int p_id, Model model) {
           Test test = new Test();

           String url = "jdbc:mysql://localhost:3306/hospital";
           String username = "root";
           String password = "gayatri@234123";

           String query="select result from test where p_id=?";

           try (Connection connection = DriverManager.getConnection(url, username, password);
                PreparedStatement ps = connection.prepareStatement(query)) {

               ps.setInt(1,p_id);

               try(ResultSet rs = ps.executeQuery()) {

                   if(rs.next()){

                       test.setResult(rs.getString("result"));

                       model.addAttribute("test", test);
                   }

               }
           }catch (SQLException e){

               e.printStackTrace();
           }
           return "testresult1";
       }
    @GetMapping("/testresults2")
    public String getAllDetails(Model model) {
        List<Test> testList = new ArrayList<>();
        List<Patients> patientList = new ArrayList<>();

        String url = "jdbc:mysql://localhost:3306/hospital";
        String username = "root";
        String password = "gayatri@234123";

        String query="select patient_name,result from test join patients on patients.id=test.p_id";
        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement ps = connection.prepareStatement(query)) {

            try (ResultSet rs=ps.executeQuery()){

                while(rs.next()){


                    Test test = new Test();
                    Patients patient=new Patients();

                    patient.setPatient_name(rs.getString("patient_name"));
                    test.setResult(rs.getString("result"));

                    patientList.add(patient);
                    testList.add(test);


                }
                model.addAttribute("patient",patientList);
                model.addAttribute("test",testList);
            }
        }catch (SQLException e) {
            e.printStackTrace();
        }
        return "testresults2";
    }
}
