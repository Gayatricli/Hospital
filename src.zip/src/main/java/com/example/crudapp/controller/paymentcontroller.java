package com.example.crudapp.controller;

import com.example.crudapp.model.Payment;
import org.springframework.stereotype.Controller;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.sql.*;

@Controller
public class paymentcontroller {

    @GetMapping("/fillform/{patient_id}")
    public String fillForm(@PathVariable("patient_id") int patient_id, Model model) {
        model.addAttribute("patient_id", patient_id);
        model.addAttribute("payment", new Payment());
        return "fillform";

    }
    @GetMapping("/getpaymentdetails/{patient_id}")

    public String getpaymentdetails(@PathVariable("patient_id") int patient_id, Model model) {

        Payment payment = new Payment();

        String url = "jdbc:mysql://localhost:3306/hospital";
        String username = "root";
        String password = "gayatri@234123";
        String query="select payment_status from payment where patient_id=?";

        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement ps = connection.prepareStatement(query)) {
             ps.setInt(1, patient_id);
             try(ResultSet rs = ps.executeQuery()) {
                 if (rs.next()) {
                     payment.setPayment_status(rs.getString("payment_status"));


                     model.addAttribute("payment", payment);

                 }
             }
        }catch(SQLException e){
            e.printStackTrace();
        }
        return "getpaymentdetails";
    }

    @GetMapping("/staff")
    public String getStaffPage() {
        return "staff";
    }
    @GetMapping("/makepayment")
    public String makepayment(Model model) {
        model.addAttribute("payment", new Payment());
        return "makepayment";
    }

    @PostMapping("/paymentdone")
    public String paymentdone(@ModelAttribute("payment") Payment payment) {
        String url = "jdbc:mysql://localhost:3306/hospital";
        String username = "root";
        String password = "gayatri@234123";
        String query = "insert into payment(patient_id,patient_name,amount) values(?,?,?)";
        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, payment.getPatient_id());
            ps.setString(2,payment.getPatient_name());
            ps.setInt(3, payment.getAmount());

            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();

        }

        return "paymentdone";
    }
    @GetMapping("/changepayment")
    public String changepayment(Model model) {
        model.addAttribute("payment", new Payment());
        return "changepayment";
    }
    @PostMapping("/updatedpay")
    public String changePaymentStatus(@ModelAttribute("payment")Payment payment) {
        String url = "jdbc:mysql://localhost:3306/hospital";
        String username = "root";
        String password = "gayatri@234123";
        String query = "update payment set payment_status = ? where amount=? ";
        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement ps = connection.prepareStatement(query)) {
             ps.setString(1,payment.getPayment_status());
             ps.setInt(2,payment.getAmount());
            ps.executeUpdate();

        }catch (SQLException e) {
            e.printStackTrace();
        }
        return "updatedpay";
    }



}
