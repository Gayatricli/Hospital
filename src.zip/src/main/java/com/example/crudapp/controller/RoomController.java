package com.example.crudapp.controller;


import com.example.crudapp.model.Patients;
import com.example.crudapp.model.Room;
import com.example.crudapp.service.RoomService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import java.sql.*;

@Controller
public class RoomController {

    @Autowired
    private RoomService roomService;

    @GetMapping("/roomform1/{room_id}")
    public String getForm1(@PathVariable("room_id") int room_id, Model model) {
        Room room = new Room();
        model.addAttribute("room_id", room_id);
        model.addAttribute("room",room);
        return "roomform1";
    }

    @GetMapping("/roomview2/{room_id}")
    public String getRoomDetails(@PathVariable("room_id") int room_id, Model model) {
        Room room = new Room();

        String url = "jdbc:mysql://localhost:3306/hospital";
        String username = "root";
        String password = "gayatri@234123";

        String query="select occupied from room where room_id=?";

        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement ps = connection.prepareStatement(query)) {

            ps.setInt(1, room_id);
            try (ResultSet rs=ps.executeQuery()){
                if(rs.next()){

                    room.setOccupied(rs.getString("occupied"));

                    model.addAttribute("room", room);
                }
            }
        } catch (SQLException e){
            e.printStackTrace();
        }

         return "roomview2";
    }

    @GetMapping("/roomview1")
    public ModelAndView getAllRooms(Model model) {
        ModelAndView mav = new ModelAndView();
        mav.setViewName("roomview1");
        model.addAttribute("room", roomService.getAllRooms());
        return mav;

    }
    @GetMapping("/roomjoin1")
    public String getDetails(Model model) {

        Room room = new Room();
        Patients patients = new Patients();

        String url = "jdbc:mysql://localhost:3306/hospital";
        String username = "root";
        String password = "gayatri@234123";

        String query="select patient_name,room_number from room join patients on room.patient_id = patients.id";

        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement ps = connection.prepareStatement(query)) {
            try (ResultSet rs = ps.executeQuery()) {
                if(rs.next()){

                    patients.setPatient_name(rs.getString("patient_name"));
                    room.setRoom_number(rs.getInt("room_number"));



                    model.addAttribute("patients", patients);
                    model.addAttribute("room", room);


                }
            }
        }catch (SQLException e){
            e.printStackTrace();
        }

       return "roomjoin1";
    }
    @GetMapping("/roomform3/{patient_id}")
    public String getForm3(@PathVariable("patient_id") int patient_id ,Model model) {
        model.addAttribute("room", new Room());
        model.addAttribute("patient_id", patient_id);
        return "roomform3";
    }
    @GetMapping("/useresult1/{patient_id}")
    public String getRoomNumber(@PathVariable("patient_id") int patient_id, Model model) {
        Room room = new Room();

        String url = "jdbc:mysql://localhost:3306/hospital";
        String username = "root";
        String password = "gayatri@234123";

        String query="select room_number from room where patient_id=?";


        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement ps = connection.prepareStatement(query)) {

            ps.setInt(1, patient_id);

            try(ResultSet rs=ps.executeQuery()){

                if(rs.next()){

                    room.setRoom_number(rs.getInt("room_number"));
                    model.addAttribute("room", room);
                }
            }
        }catch (SQLException e){
            e.printStackTrace();
        }

       return "useresult1";

        }
    @GetMapping("/roomform2")
    public String showPage(Model model){
        model.addAttribute("room", new Room());
        return "roomform2";
    }
    @PostMapping("/roominsert")
    public String newRoom(@ModelAttribute("room") Room room) {

        String url = "jdbc:mysql://localhost:3306/hospital";
        String username = "root";
        String password = "gayatri@234123";

        String query="insert into room(room_id,room_type,room_number,occupied)values(?,?,?,?)";

        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement ps = connection.prepareStatement(query)) {



                    ps.setInt(1,room.getRoom_id());
                    ps.setString(2,room.getRoom_type());
                    ps.setInt(3,room.getRoom_number());
                    ps.setString(4,room.getOccupied());

                    ps.executeUpdate();



                }
        catch (SQLException e){
            e.printStackTrace();
        }

        return "roominsert";
    }

}
