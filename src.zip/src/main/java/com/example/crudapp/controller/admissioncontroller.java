package com.example.crudapp.controller;

import com.example.crudapp.model.HospitalData;
import com.example.crudapp.model.Patients;
import org.springframework.stereotype.Controller;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@Controller
public class admissioncontroller {

    @GetMapping("/new")
    public String showPage(Model model){
        model.addAttribute("patient", new Patients());
        return "new";
    }

    @PostMapping("/added")
    public String addPatient(@ModelAttribute("patient") Patients patient) {
        String url = "jdbc:mysql://localhost:3306/hospital";
        String username = "root";
        String password = "gayatri@234123";
        String query = "INSERT INTO patients(id,patient_name,doctor_name,discharge_status)VALUES(?,?,?,?)";
        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, patient.getId());
            ps.setString(2, patient.getPatient_name());
            ps.setString(3, patient.getDoctor_name());
            ps.setString(4, patient.getDischarge_status());
            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();

        }
        return "added";
    }

    @GetMapping("/save")
    public String showAdmissionPage(Model model) {
        model.addAttribute("hospitalData", new HospitalData());
        return "admission"; // JSP page that shows the form

    }
    @GetMapping("/read/{id}")
    public String readData(@PathVariable int id, Model model) {
        model.addAttribute("id",id);
        model.addAttribute("hospital", new HospitalData());
        return "read";
    }
    @PostMapping("/retrieved/{id}")
    public String readHospitalData(@PathVariable("id") int id,Model model) {
        String url = "jdbc:mysql://localhost:3306/hospital";
        String username = "root";
        String password = "gayatri@234123";
        String query="SELECT id,hospital_data.date,mobile,hospital_data.name,reason FROM hospital_data WHERE id=?";
        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement ps = connection.prepareStatement(query)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()){
                    HospitalData hospitalData = new HospitalData();
                    hospitalData.setId(rs.getInt("id"));
                    hospitalData.setDate(Integer.parseInt(rs.getString("date")));
                    hospitalData.setMobile(rs.getLong("mobile"));
                    hospitalData.setName(rs.getString("name"));
                    hospitalData.setReason(rs.getString("reason"));

                    // Add hospitalData to the model
                    model.addAttribute("hospitalData", hospitalData);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return "retrieved";
    }

    @GetMapping("/deletion/{id}")
    public String showDeletionPage(@PathVariable int id ,Model model) {
        model.addAttribute("id", id);
        return "delete";
    }

    @PostMapping("/deleted/{id}")
    public String deleteHospitalData(@PathVariable("id") int id) {
        String url = "jdbc:mysql://localhost:3306/hospital";
        String username = "root";
        String password = "gayatri@234123";
        String query = "DELETE FROM hospital_data WHERE id = ?";
        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement ps = connection.prepareStatement(query)) {

            ps.setInt(1,id);
            ps.executeUpdate();


        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return "deleted";
    }

    //@GetMapping("/result")
    //public String showResultPatient(Model model)throws SQLException{
        //Patients p = new Patients();
       // String url = "jdbc:mysql://localhost:3306/hospital";
       // String username = "root";
       // String password = "gayatri@234123";
      //  String query = "SELECT patient_name,discharge_status FROM patients";
       // try (Connection connection = DriverManager.getConnection(url, username, password);
             //PreparedStatement ps = connection.prepareStatement(query)){
             // try (ResultSet rs = ps.executeQuery()){
                  //if(rs.next()) {
                     // p.setPatient_name(rs.getString("patient_name"));
                     // p.setDischarge_status(rs.getString("discharge_status"));

                //  }
            //  }

       // }catch (SQLException e) {
            //e.printStackTrace();
        //}
        //model.addAttribute("p", p);
       // return "result";
  //  }
    @GetMapping("/join")
    public String showJoinPage(Model model) throws SQLException {
        List<HospitalData> hospitalDataList =new ArrayList<HospitalData>();
        List<Patients> patientList = new ArrayList<>();
        String url = "jdbc:mysql://localhost:3306/hospital";
        String username = "root";
        String password = "gayatri@234123";
        String query = "SELECT patient_name,doctor_name,reason FROM patients JOIN hospital_data ON patients.admission_id=hospital_data.id";
        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement ps = connection.prepareStatement(query)) {
            try (ResultSet rs = ps.executeQuery()) {
                while(rs.next()) {
                    Patients p = new Patients();
                    HospitalData hospitalData = new HospitalData();

                    p.setPatient_name(rs.getString("patient_name"));
                    p.setDoctor_name(rs.getString("doctor_name"));
                    hospitalData.setReason(rs.getString("reason"));

                    patientList.add(p);
                    hospitalDataList.add(hospitalData);


                }

                model.addAttribute("p",patientList);
                model.addAttribute("hospitalData",hospitalDataList);

            } catch (SQLException e) {
                e.printStackTrace();
            }



        }
        return "join";
    }
    @PostMapping("/add")
    public String create(@ModelAttribute("hospitalData") HospitalData hospitalData) {
        // Database connection parameters
        String url = "jdbc:mysql://localhost:3306/hospital";
        String username = "root";
        String password = "gayatri@234123";

        // SQL insert query
        String query = "INSERT INTO hospital_data (id, date, mobile, name, reason) VALUES (?, ?, ?, ?, ?)";

        try (Connection connection = DriverManager.getConnection(url,username,password);
             PreparedStatement ps = connection.prepareStatement(query)) {

            // Set parameters for the query
            ps.setInt(1, hospitalData.getId());
            ps.setString(2, hospitalData.getDate());  // assuming date is String here
            ps.setLong(3, hospitalData.getMobile());
            ps.setString(4, hospitalData.getName());
            ps.setString(5, hospitalData.getReason());

            // Execute update
            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();

        }
        // After successful insertion, return success page
        return "add";
    }
    @GetMapping("/update/{id}")
    public String showUpdatePage(@PathVariable("id") int id,Model model) {
        model.addAttribute("id",id);
        model.addAttribute("hospitalData", new HospitalData());
        return "updatehere";
    }
    @PostMapping("/success/{id}")
    public String update(@PathVariable("id") int id,@ModelAttribute("hospitalData") HospitalData hospitalData) {
        hospitalData.setId(id);
        String url = "jdbc:mysql://localhost:3306/hospital";
        String username = "root";
        String password = "gayatri@234123";

        String query="UPDATE hospital_data SET date = ?, mobile = ?, name = ?, reason = ? WHERE id = ?";
        try (Connection connection = DriverManager.getConnection(url,username,password);
             PreparedStatement ps = connection.prepareStatement(query)) {

            // Set parameters for the query
            ps.setString(1,hospitalData.getDate());
            ps.setLong(2,hospitalData.getMobile());  // assuming date is String here
            ps.setString(3,hospitalData.getName());
            ps.setString(4, hospitalData.getReason());
            ps.setInt(5, hospitalData.getId());

            // Execute update
            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();

        }
        return "success";

    }
}
