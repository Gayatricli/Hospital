package com.example.crudapp.controller;


import com.example.crudapp.model.HospitalData;
import com.example.crudapp.service.HospitalDataService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.Optional;

@Controller
//@RequestMapping("/hospital")

public class HospitalDataController {

    @Autowired
    HospitalDataService hospitalDataService;


    // @GetMapping("")
    // public List<HospitalData> getAllHospitalData(){
    //  return hospitalDataService.getAllHospitalData();
    //}
    @RequestMapping(value = {"/", "/home", "/index"})
    public ModelAndView getAllHospitalData() {
        ModelAndView mav = new ModelAndView("patientlist");
        hospitalDataService.getAllHospitalData();
        mav.addObject("hospitalData", hospitalDataService.getAllHospitalData());
        return mav;

    }
    @GetMapping("/find/{id}")
    public Optional<HospitalData> getHospitalDataById(@PathVariable("id") Integer id) {
        return hospitalDataService.findById(id);

    }

    //@RequestMapping("/save")
    //public ModelAndView saveHospitalData(@ModelAttribute("hospitalData") HospitalData hospitalData) {
    // ModelAndView mav = new ModelAndView("patientlist");
    //hospitalDataService.create(hospitalData);
    //mav.addObject("hospitalData", hospitalDataService.getAllHospitalData());
    // return mav;

    //}
    //@PutMapping("/update")
    //public HospitalData updateHospitalData(@RequestBody HospitalData hospitalData) {
        //return hospitalDataService.update(hospitalData);
    //}
    //@DeleteMapping("/delete/{id}")
    // public String deleteHospitalData(@PathVariable Integer id) {
    //return hospitalDataService.deleteHospitalData(id);
    //}
}


