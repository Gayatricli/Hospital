package com.example.crudapp.controller;

import com.example.crudapp.model.HospitalData;
import com.example.crudapp.model.Patients;
import com.example.crudapp.model.Treatment;


import com.example.crudapp.service.PatientsService;
import com.example.crudapp.service.TreatmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.sql.*;

@Controller
public class Treatmentcontroller {
    @Autowired
    TreatmentService treatmentService;

    @GetMapping("/results2")
    public String getAllData(Model model){
        Treatment treatment = new Treatment();
        Patients patients = new Patients();
        String url = "jdbc:mysql://localhost:3306/hospital";
        String username = "root";
        String password = "gayatri@234123";

        String query = "select patient_name,treatment_describe from treatment join patients on treatment.patient_id =patients.id";
        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement ps = connection.prepareStatement(query)) {
            try (ResultSet rs=ps.executeQuery()){

                if(rs.next()){
                    patients.setPatient_name(rs.getString("patient_name"));
                    treatment.setTreatment_describe(rs.getString("treatment_describe"));

                    model.addAttribute("patients", patients);
                    model.addAttribute("treatment", treatment);

                }

            }
        }catch (SQLException e) {
            e.printStackTrace();
        }

        return "results2";

    }

    @GetMapping("/entertreatmentid/{treatment_id}")
    public String getForm(@PathVariable("treatment_id") int treatment_id, Model model) {
        model.addAttribute("treatment_id", treatment_id);
        model.addAttribute("treatment", new Treatment());
        return "entertreatmentid";
    }
    @GetMapping("/treatmentdetails/{treatment_id}")
    public String getTreatmentById(@PathVariable("treatment_id")int treatment_id, Model model) {
        Treatment treatment = new Treatment();
        String url = "jdbc:mysql://localhost:3306/hospital";
        String username = "root";
        String password = "gayatri@234123";
        String query = "select treatment_id,doctor_id,treatment_describe,start_date,end_date from treatment where treatment_id=?";
        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement ps = connection.prepareStatement(query)) {

            ps.setInt(1, treatment_id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    treatment.setTreatment_id(rs.getInt("treatment_id"));
                    treatment.setDoctor_id(rs.getInt("doctor_id"));
                    treatment.setTreatment_describe(rs.getString("treatment_describe"));
                    treatment.setStart_date(rs.getInt("start_date"));
                    treatment.setEnd_date(rs.getInt("end_date"));

                    model.addAttribute("treatment", treatment);

                }


            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return "treatmentdetails";
    }
    @GetMapping("/success2")
    public ModelAndView getAllTreatments(){
        ModelAndView mav = new ModelAndView("success2");
        treatmentService.getAllTreatments();
        mav.addObject("treatment", treatmentService.getAllTreatments());
        return mav;
    }
    @GetMapping("/success1")
    public String getAllTreatments(Model model) {
         Treatment treatment = new Treatment();
         String url = "jdbc:mysql://localhost:3306/hospital";
         String username = "root";
         String password = "gayatri@234123";
         String query = "select * from treatment";
         try (Connection connection = DriverManager.getConnection(url, username, password);
                   PreparedStatement ps = connection.prepareStatement(query)) {
             try(ResultSet rs=ps.executeQuery()){
                 if(rs.next()){
                     treatment.setTreatment_id(rs.getInt("treatment_id"));
                     treatment.setDoctor_id(rs.getInt("doctor_id"));
                     treatment.setTreatment_describe(rs.getString("treatment_describe"));
                     treatment.setStart_date(rs.getInt("start_date"));
                     treatment.setEnd_date(rs.getInt("end_date"));

                     model.addAttribute("treatment", treatment);

                 }

             }
         }catch (SQLException e){
             e.printStackTrace();
         }
         return "success1";

        }
    @GetMapping("/show")
    public String show(Model model) {
        model.addAttribute("hospital", new HospitalData());
        return "welcome";
    }
    @GetMapping("/forstaff")
    public String forstaff(Model model) {
        model.addAttribute("hospital", new HospitalData());
        return "forstaff";
    }
    @GetMapping("/forusers")
    public String forusers(Model model) {
        model.addAttribute("hospital", new HospitalData());
        return "forusers";
    }
    @GetMapping("/fordoctors")
    public String fordoctors(Model model) {
        model.addAttribute("hospital", new HospitalData());
        return "fordoctors";
    }
}




