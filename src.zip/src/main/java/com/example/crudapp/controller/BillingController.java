package com.example.crudapp.controller;


import com.example.crudapp.model.Billing;
import com.example.crudapp.model.Payment;
import com.example.crudapp.service.BillingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.servlet.ModelAndView;

import java.sql.*;

@Controller
public class BillingController  {

    @Autowired
    private BillingService billingService;


    Billing billing = new Billing();

    @GetMapping("/billingdetails1")
    public ModelAndView getBillingDetails(){
        Billing billing = new Billing();
        ModelAndView mav = new ModelAndView("billingdetails1");
        mav.addObject("billing",billingService.findAll());
        return mav;
    }
    @GetMapping("/billingdetails2")
    public String getBillingDetails2(Model model){

         Billing billing = new Billing();
         Payment payment = new Payment();
         String url = "jdbc:mysql://localhost:3306/hospital";
         String username = "root";
         String password = "gayatri@234123";

         String query="select patient_name,billing.payment_status from billing join payment on billing.id_patient=payment.patient_id";
        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement ps = connection.prepareStatement(query)) {
            try (ResultSet rs = ps.executeQuery()) {
                if(rs.next()){
                    payment.setPatient_name(rs.getString("patient_name"));
                    billing.setPayment_status(rs.getString("payment_status"));

                    model.addAttribute("billing",billing);
                    model.addAttribute("payment",payment);

                }
            }
        }catch (SQLException e){
            e.printStackTrace();
        }
        return "billingdetails2";

    }
    @GetMapping("/billform1/{billing_id}")
    public String getForm(@PathVariable("billing_id") int billing_id,Model model){
        Billing billing = new Billing();
        model.addAttribute("billing",billing);
        model.addAttribute("billing_id",billing_id);
        return "billform1";
    }
    @GetMapping("/billingdetails3/{billing_id}")
    public String getPaymentStatus(@PathVariable("billing_id") int billing_id,Model model){
        Billing billing = new Billing();
        String url = "jdbc:mysql://localhost:3306/hospital";
        String username = "root";
        String password = "gayatri@234123";

        String query ="select payment_status from billing where billing_id=?";
        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1,billing_id);
            try (ResultSet rs=ps.executeQuery()){
                if(rs.next()){
                    billing.setPayment_status(rs.getString("payment_status"));

                    model.addAttribute("billing",billing);
                }
            }
        }catch (SQLException e){
            e.printStackTrace();
        }
        return "billingdetails3";
    }
    @GetMapping("/billform2/{billing_id}")
    public String getForm2(@PathVariable("billing_id") int billing_id,Model model){
        Billing billing = new Billing();
        model.addAttribute("billing",billing);
        model.addAttribute("billing_id",billing_id);
        return "billform2";
    }
    @GetMapping("/billingdetails4/{billing_id}")
    public String getBillingDetails4(@PathVariable("billing_id") int billing_id,Model model){
        Billing billing = new Billing();
        String url = "jdbc:mysql://localhost:3306/hospital";
        String username = "root";
        String password = "gayatri@234123";

        String query="select total_amount from billing where billing_id=?";
        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1,billing_id);
            try (ResultSet rs=ps.executeQuery()){
                if(rs.next()){
                    billing.setTotal_amount(rs.getInt("total_amount"));

                    model.addAttribute("billing",billing);
                }
            }


    }catch (SQLException e){
         e.printStackTrace();
    }
        return "billingdetails4";
}
}
