package com.example.crudapp.controller;

import com.example.crudapp.model.Billing;
import com.example.crudapp.model.Treatment;
import com.example.crudapp.service.MedicineService;
import com.example.crudapp.model.Medicine;
import org.springframework.stereotype.Controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.servlet.ModelAndView;

import java.sql.*;

@Controller
public class MedicineController {
    @Autowired
    MedicineService medicineService;


    @GetMapping("/medicineresult1")
    public ModelAndView medicineResult1() {
        ModelAndView mav = new ModelAndView("medicineresult1");
        mav.addObject("medicine", medicineService.getAllMedicine());
        return mav;
    }

    @GetMapping("/medicine2")
    public String getMedicineName(Model model)throws SQLException {

        Treatment treatment=new Treatment();
        Medicine medicine=new Medicine();

        String url = "jdbc:mysql://localhost:3306/hospital";
        String username = "root";
        String password = "gayatri@234123";

        String query="SELECT treatment_id,treatment_describe,medicine_name FROM treatment JOIN medicine ON treatment.treatment_id = medicine.id";

        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement ps = connection.prepareStatement(query)){

            try (ResultSet rs=ps.executeQuery()){

                if(rs.next()){
                    treatment.setTreatment_id(rs.getInt("treatment_id"));
                    treatment.setTreatment_describe(rs.getString("treatment_describe"));
                    medicine.setMedicine_name(rs.getString("medicine_name"));

                    model.addAttribute("treatment", treatment);
                    model.addAttribute("medicine", medicine);


                    
                }
        }
    }catch (SQLException e){
            e.printStackTrace();
        }
        return "medicine2";
    }
    @GetMapping("/medicineform1/{medicine_id}")
    public String medicineForm1(@PathVariable("medicine_id") int medicine_id, Model model)throws SQLException {
         model.addAttribute("medicine_id", medicine_id);
         model.addAttribute("medicine", new Medicine());
         return "medicineform1";

    }
    @GetMapping("/medicine3/{medicine_id}")
    public String getDetails(@PathVariable("medicine_id") int medicine_id, Model model)throws SQLException {
        Medicine medicine=new Medicine();

        String url = "jdbc:mysql://localhost:3306/hospital";
        String username = "root";
        String password = "gayatri@234123";

        String query="select medicine_name,price from medicine where medicine_id=?";
        try (Connection connection = DriverManager.getConnection(url, username, password)){
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setInt(1, medicine_id);
            try (ResultSet rs=ps.executeQuery()){
                if(rs.next()){
                    medicine.setMedicine_name(rs.getString("medicine_name"));
                    medicine.setPrice(rs.getInt("price"));

                    model.addAttribute("medicine", medicine);
                }
            }
        }catch (SQLException e){
            e.printStackTrace();
        }
        return "medicine3";

    }

}
