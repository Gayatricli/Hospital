package com.example.crudapp.controller;

import com.example.crudapp.model.HospitalData;
import com.example.crudapp.service.HospitalDataService;

import com.example.crudapp.service.PatientsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class Patientscontroller {
    @Autowired

    PatientsService patientsService;

    @RequestMapping(value = {"/results"})
    public ModelAndView getAllPatients() {
        ModelAndView mav = new ModelAndView("result");
        patientsService.getAllPatients();
        mav.addObject("patient", patientsService.getAllPatients());
        return mav;
    }

}
